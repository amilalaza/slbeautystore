<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
?>
<p class="hp-form__action hp-form__action--user-login"><?php esc_html_e( 'Already have an account?', 'hivepress' ); ?> <a href="#user_login_modal"><?php esc_html_e( 'Sign In', 'hivepress' ); ?></a></p>
