<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
?>
<a href="#user_password_request_modal" class="hp-form__action hp-form__action--user-password-request"><?php esc_html_e( 'Forgot password?', 'hivepress' ); ?></a>
