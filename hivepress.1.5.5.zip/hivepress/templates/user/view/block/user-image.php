<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
?>
<div class="hp-vendor__image">
	<?php echo get_avatar( $user->get_id(), 400 ); ?>
</div>
