<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
?>
<h4 class="hp-vendor__name"><?php echo esc_html( $user->get_display_name() ); ?></h4>
