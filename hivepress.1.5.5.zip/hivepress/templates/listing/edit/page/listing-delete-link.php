<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
?>
<a href="#listing_delete_modal" class="hp-listing__action hp-listing__action--delete hp-link"><i class="hp-icon fas fa-times"></i><span><?php esc_html_e( 'Delete', 'hivepress' ); ?></span></a>
