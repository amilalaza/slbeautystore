<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
?>
<span><?php echo esc_html( $listing->get_title() ); ?></span>
