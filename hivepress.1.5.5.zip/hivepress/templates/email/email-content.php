<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

echo $email->get_body();
